
#include "lio/super_lio.h"
#include "lio/ouster_scan_history.hpp"

#include <sys/resource.h>
#include <tbb/parallel_for.h>
#include <tbb/blocked_range.h>
#include <tbb/concurrent_vector.h>
#include <tbb/enumerable_thread_specific.h>
#include <algorithm>
#include <cstdint>
#include <iomanip>
#include <limits>


using namespace BASIC;

namespace LI2Sup{

namespace {
bool auditHasAcquisitionBracket(const std::vector<DynamicState>& history,double time){
  if(history.size()<2||time>history.back().time)return false;
  auto tail=std::upper_bound(history.begin(),history.end(),time,
      [](double t,const DynamicState& s){return t<s.time;});
  if(tail==history.end())return history.back().R.allFinite()&&history.back().p.allFinite();
  auto head=tail==history.begin()?tail:std::prev(tail);
  if(head==tail){
    auto next=std::next(tail);if(next==history.end())return false;tail=next;
  }
  return tail->time>head->time&&head->R.allFinite()&&tail->R.allFinite()&&
    head->p.allFinite()&&head->v.allFinite()&&tail->a.allFinite();
}
}

inline bool calc_plane_coeff(const int N, const std::array<V3, 5>& points, std::array<double, 4>& abcd)
{
  Eigen::Vector3d normvec;
  if (N == 5) {
    Eigen::Matrix<double, 5, 3> A;
    Eigen::Matrix<double, 5, 1> b;
    for (int j = 0; j < 5; j++) {
      A.row(j) = points[j].cast<double>();
      b(j) = -1.0;
    }
    normvec = A.colPivHouseholderQr().solve(b);
  }
  else {
    Eigen::Matrix<double, 4, 3> A;
    Eigen::Matrix<double, 4, 1> b;

    for (int j = 0; j < N; j++) {
      A.row(j) = points[j].cast<double>();
      b(j) = -1.0;
    }
    normvec = A.colPivHouseholderQr().solve(b);
  }

  double n = normvec.norm();
  if (n < 1e-6f) return false;

  abcd[3] = 1.0 / n;
  normvec *= abcd[3];
  abcd[0] = normvec[0];
  abcd[1] = normvec[1];
  abcd[2] = normvec[2];
  
  for (int i = 0; i < N; ++i) {
    const V3& p = points[i];
    auto dist = abcd[0] * p(0) + abcd[1] * p(1) + abcd[2] * p(2) + abcd[3];
    if (std::abs(dist) > 0.1) return false;
  }
  return true;
}


inline bool compute_error(
  const std::array<double, 4>& abcd, const V3& point, 
  const float length, scalar& error)
{
  error = abcd[0] * point[0] + abcd[1] * point[1] + abcd[2] * point[2] + abcd[3];
  return length > 81 * error * error;
}


void SuperLIO::init(){
  ros::NodeHandle photo_nh;
  std::string time_audit_path;
  photo_nh.getParam("/p2r/time_audit_path",time_audit_path);
  if(!time_audit_path.empty()&&g_lidar_type==LID_TYPE::OUSTER){
    time_audit_.open(time_audit_path);
    if(!time_audit_)throw std::runtime_error("cannot write P2R time audit");
    time_audit_<<std::setprecision(17)
      <<"frame,phase,ros_message_stamp,max_t_all_raw_offset_s,max_t_valid_raw_offset_s,"
        "max_t_geometry_after_filter_rate_offset_s,current_lidar_end_time,proposed_full_scan_end_time,"
        "imu_last_available_to_sync,imu_last_consumed,propagated_history_first,propagated_history_last,"
        "raw_coin_points,raw_coin_points_after_current_end,raw_coin_points_after_history_back,"
        "current_motion_fallback_points,geometry_points,imu_bracket_span_s,imu_support_issue\n";
  }
  std::string geometry_rows_path;
  photo_nh.getParam("/p2s/geometry_rows_path",geometry_rows_path);
  if(!geometry_rows_path.empty()){
    geometry_rows_audit_.open(geometry_rows_path,std::ios::binary|std::ios::trunc);
    if(!geometry_rows_audit_)throw std::runtime_error("cannot write P2-S geometry row audit");
  }
  photo_ = std::make_unique<cube::PhotoObservation>(photo_nh);
  Eigen::Matrix4d T_IL=Eigen::Matrix4d::Identity();
  T_IL.topLeftCorner<3,3>()=g_lidar_imu.R_.cast<double>();
  T_IL.topRightCorner<3,1>()=g_lidar_imu.t_.cast<double>();
  coin_=std::make_unique<cube::coin::CoinObservation>(photo_nh,T_IL);
  ivox_.reset(new OctVoxMapType(OctVoxMapType::Options{g_ivox_resolution, g_ivox_capacity}));
  kf_.reset(new ESKF());
  data_wrapper_->setESKF(kf_);
  
  scan_undistort_full_.reset(new PointCloudType());
  ds_undistort_.reset(new PointCloudType());
  world_pc_.reset(new PointCloudType());
  ds_world_.reset(new PointCloudType());

  if(g_save_map){
    point_map_.reset(new PointCloudType());
  }
  
  points_world_v3_.reserve(21000);
  abcd_vec_.resize(20000);
  effect_knn_idxs_.resize(20000);
  voxel_grid_fliter_.setLeafSize(g_voxel_fliter_size);

  state_fn_ = &SuperLIO::stateWaitKFInit;

  LOG(INFO) << GREEN << " ---> [SuperLIO]: initialized." << RESET;
}


void SuperLIO::stateWaitKFInit()
{
  if (kf_init()) {
    state_fn_ = &SuperLIO::stateWaitMapInit;
    LOG(INFO) << GREEN << " ---> [SuperLIO]: KF init done" << RESET;
  }
}

void SuperLIO::stateWaitMapInit()
{
  if (map_init()) {
    kf_->init_ = true;
    state_fn_ = &SuperLIO::stateProcess;
    LOG(INFO) << GREEN << " ---> [SuperLIO]: Map init done" << RESET;
  }
}

void SuperLIO::process(){
  if(!data_wrapper_->sync_measure(measures_)){
    return;
  }
  const bool normal_frame=state_fn_==&SuperLIO::stateProcess;
  (this->*state_fn_)();
  if(time_audit_&&measures_.lidar.time_audit.enabled){
    const auto& audit=measures_.lidar.time_audit;
    const double start=measures_.lidar.start_time;
    const double end=measures_.lidar.end_time;
    const bool has_history=normal_frame&&!propagate_states_.empty();
    const double first=has_history?propagate_states_.front().time:
      std::numeric_limits<double>::quiet_NaN();
    const double back=has_history?propagate_states_.back().time:
      std::numeric_limits<double>::quiet_NaN();
    std::size_t after_end=0,after_back=0,fallback=0;
    for(double offset:audit.valid_raw_offsets){
      const double acquisition=start+offset;
      after_end+=acquisition>end;
      if(has_history){
        after_back+=acquisition>back;
        fallback+=!auditHasAcquisitionBracket(propagate_states_,acquisition);
      }
    }
    time_audit_<<time_audit_frame_++<<','<<(normal_frame?"normal":"initialization")<<','
      <<start<<','<<audit.max_offset_all_raw<<','<<audit.max_offset_valid_raw<<','
      <<audit.max_offset_geometry<<','<<end<<','<<start+audit.max_offset_valid_raw<<','
      <<audit.imu_last_available<<','<<audit.imu_last_consumed<<','<<first<<','<<back<<','
      <<audit.valid_raw_points<<','<<after_end<<',';
    if(has_history)time_audit_<<after_back<<','<<fallback;
    else time_audit_<<',';
    time_audit_<<','<<audit.geometry_points<<','<<audit.imu_bracket_span_s<<','
      <<measures_.lidar.imu_support_issue<<std::endl;
  }
}


bool SuperLIO::kf_init(){
  static int imu_cout = 0;
  static V3 mean_gyro = V3::Zero();
  static V3 mean_acce = V3::Zero();

  for(auto& imu: measures_.imu){
    imu_cout ++;
    mean_gyro += (imu.gyr - mean_gyro) / imu_cout;
    mean_acce += (imu.acc - mean_acce) / imu_cout;
  }

  /// 100 Hz for 1 second.
  if(imu_cout < 50){
    return false;
  }

  V3 gravity = - mean_acce * g_gravity_norm / mean_acce.norm();
  V3 ref_gravity(0, 0, - g_gravity_norm);
  M3 init_rot = Quat::FromTwoVectors(gravity, ref_gravity).toRotationMatrix();
  V3 n = init_rot.col(0);
  double yaw = atan2(n(1), n(0));

  M3 R_yaw_inv = Eigen::AngleAxis<scalar>(-yaw, V3::UnitZ()).toRotationMatrix(); 

  // init_rot represents the IMU orientation after gravity alignment (level orientation).
  // Perform LiDAR leveling correction, then transform the orientation into the robot frame.
  M3 rot = g_lidar_robo_yaw * R_yaw_inv * init_rot;  

  ESKF::Options options;
  options.gyro_var_ = g_imu_ng;
  options.acce_var_ = g_imu_na;
  options.bias_gyro_var_ = g_imu_nbg;
  options.bias_acce_var_ = g_imu_nba;
  options.num_iterations_ = g_kf_max_iterations;
  options.quit_eps_ = g_kf_quit_eps;

  float imu_scale = g_gravity_norm / mean_acce.norm();
  kf_->SetInitialConditions(options, mean_gyro, V3::Zero(), imu_scale, ref_gravity);
  auto state = kf_->GetSysState();
  state.R = SO3(rot);
  state.p = g_odom_robo.t_;        // By default, the robot frame is used as the reference origin.
  state.timestamp = measures_.imu.back().secs;
  kf_->SetX(state);
  sys_init_pose_ = kf_->GetSE3();
  return true;
}


bool SuperLIO::map_init(){
  frame_num_++;

  std::size_t ptsize = measures_.lidar.pc->size();
  points_world_v3_.resize(ptsize);

  const SE3 transform = sys_init_pose_ * g_lidar_imu;

  tbb::parallel_for(
    tbb::blocked_range<size_t>(0, ptsize),
    [&](const tbb::blocked_range<size_t>& r) {
      for (size_t idx = r.begin(); idx < r.end(); ++idx) {
        auto& point_pcl = measures_.lidar.pc->points[idx];
        V3 point_body(point_pcl.x, point_pcl.y, point_pcl.z);
        points_world_v3_[idx] = transform * point_body;
      }
    }
  );

  ivox_->insert(points_world_v3_);
  kf_->SetLastObsTime(measures_.lidar.end_time);

  if(frame_num_ > 3){
    g_flg_map_init = false;
    return true;
  }
  return false;
}


void SuperLIO::stateProcess(){
  frame_num_++;
  if(g_time_eva){
    time_record_.Evaluate([this](){Propagation_Undistort();}, "Undistort");
    time_record_.Evaluate([this]() { DownSample(); }, "DownSample");
    time_record_.Evaluate([this]() { Observe(); }, "Observe");
    time_record_.Evaluate([this]() { UpdateMap(); }, "UpdateMap");
  }else{
    Propagation_Undistort();
    DownSample();
    Observe();
    UpdateMap();
  }
  Output();
  caceData();
}


void SuperLIO::caceData(){
  if(!g_save_map) return;
  auto state = kf_->GetNavState();
  Eigen::Matrix4f transformation = Eigen::Matrix4f::Identity();
  transformation.block<3, 3>(0, 0) = state.R.R_.cast<float>();
  transformation.block<3, 1>(0, 3) = state.p.cast<float>();

  if(g_if_filter){
    pcl::transformPointCloud(*ds_undistort_, *world_pc_, transformation);
  }else{
    pcl::transformPointCloud(*scan_undistort_full_, *world_pc_, transformation);
  }

  static int scan_wait_num = 0;
  if(!world_pc_->empty()){
    *point_map_ += *world_pc_;
    scan_wait_num++;
  }

  if(g_pcd_save_interval < 0) {
    scan_wait_num = 0;
    return;
  }

  static bool rm_PCD_dir = false;
  if(!rm_PCD_dir){
    rm_PCD_dir = true;
    std::string cmd = "rm -rf " + g_save_map_dir + "/PCD";
    [[maybe_unused]] int res;
    res = system(cmd.c_str());
    cmd = "mkdir -p " + g_save_map_dir + "/PCD";
    res = system(cmd.c_str());
  }

  if (point_map_->size() > 0 && scan_wait_num >= g_pcd_save_interval) {
    pcd_index_++;
    std::string map_name(std::string(g_save_map_dir + "/PCD/scans_") + std::to_string(pcd_index_) +
                               std::string(".pcd"));
    LOG(INFO) << GREEN << " ---> current scan saved to /PCD/scans_" << pcd_index_ << "  size:  " << point_map_->size() << RESET;
    pcl::io::savePCDFileBinary(map_name, *point_map_);
    point_map_->clear();
    scan_wait_num = 0;
  }
}


void SuperLIO::ProcessCaceMap(){
  namespace fs = std::filesystem;

  std::string pcd_folder = g_save_map_dir + "/PCD";
  std::string output_map_name = g_save_map_dir + "/" + g_map_name;

  LOG(INFO) << YELLOW << " ---> Merging PCD fragments in: " << pcd_folder << RESET;

  PointCloudType::Ptr merged_map(new PointCloudType());

  int count = 0;
  for (const auto& entry : fs::directory_iterator(pcd_folder)) {
    if (entry.path().extension() == ".pcd" &&
      entry.path().filename().string().find("scans_") != std::string::npos) {
      PointCloudType::Ptr tmp_cloud(new PointCloudType());
      if (pcl::io::loadPCDFile<PointType>(entry.path().string(), *tmp_cloud) == 0) {
        *merged_map += *tmp_cloud;
        count++;
        // LOG(INFO) << GREEN << " ---> Merged: " << entry.path().filename().string() 
        //           << "   size: " << tmp_cloud->size() << RESET;
      } else {
        LOG(WARNING) << RED << " ---> Failed to load: " << entry.path().string() << RESET;
      }
    }
  }

  LOG(INFO) << YELLOW << " ---> Total merged fragments: " << count << RESET;

  PointCloudType filtered_map;

  if(g_if_filter){
    LOG(INFO) << YELLOW << " ---> Downsampling merged map before final save..." << RESET;
    pcl::VoxelGrid<PointType> voxel_filter;
    voxel_filter.setLeafSize(g_map_ds_size, g_map_ds_size, g_map_ds_size);
    
    voxel_filter.setInputCloud(merged_map);
    voxel_filter.filter(filtered_map);
  }else{
    LOG(INFO) << YELLOW << " ---> Not Downsampling merged map before final save..." << RESET;
    filtered_map = *merged_map;
  }
  
  if (filtered_map.size() > 0) {
    filtered_map.width = filtered_map.size();
    filtered_map.height = 1;
    filtered_map.is_dense = false;
  }

  pcl::io::savePCDFileBinary(output_map_name, filtered_map);

  LOG(INFO) << GREEN << " ---> Final map saved to: " << output_map_name << RESET;
  LOG(INFO) << GREEN << " ---> Final map size: " << filtered_map.size() << RESET;
}


void SuperLIO::saveMap(){
  if(!g_save_map) return;
  if(g_pcd_save_interval > 0){
    LOG(INFO) << YELLOW << " ---> Saving last cace ... " << RESET;
    if (point_map_->size() > 0) {
      pcd_index_++;
      std::string map_name(std::string(g_save_map_dir + "/PCD/scans_") + std::to_string(pcd_index_) +
                                 std::string(".pcd"));
      LOG(INFO) << GREEN << " ---> current scan saved to /PCD/scans_" << pcd_index_ << "  size:  " << point_map_->size() << RESET;
      pcl::io::savePCDFileBinary(map_name, *point_map_);
      point_map_->clear();
    }
    LOG(INFO) << GREEN << " ---> Save last cace success. " << RESET;
    LOG(INFO) << YELLOW << " ---> Process cace map ... " << RESET;
    ProcessCaceMap();
    return;
  }

  LOG(INFO) << YELLOW << " ---> Saving map..... " << RESET;
  if(!point_map_->empty()){
    std::string map_name = g_save_map_dir + "/" + g_map_name;
    LOG(INFO) << YELLOW << " ---> Save map to: " << map_name << RESET;
    pcl::VoxelGrid<PointType> voxel_fliter;
    PointCloudType latst_map;
    voxel_fliter.setInputCloud(point_map_);
    voxel_fliter.setLeafSize(g_map_ds_size, g_map_ds_size, g_map_ds_size);
    voxel_fliter.filter(latst_map);
    if(latst_map.size() > 0){
      latst_map.width = latst_map.size();
      latst_map.height = 1;
      latst_map.is_dense = false;
    }
    pcl::io::savePCDFileBinary(map_name, latst_map);
    LOG(INFO) << GREEN << " ---> Save map success. File: " << map_name << RESET;
    LOG(INFO) << GREEN << " ---> Map size: " << latst_map.size() << RESET;
  }
}


void SuperLIO::Propagation_Undistort(){
  const auto corrected_start=kf_->GetDynamicState();
  if(g_lidar_type==LID_TYPE::OUSTER)
    retainRebasedOusterHistory(propagate_states_,corrected_start,measures_.lidar.start_time);
  else{
    propagate_states_.clear();
    propagate_states_.emplace_back(corrected_start);
  }
  kf_->SetObsTime(measures_.lidar.end_time);
  for (auto &imu : measures_.imu) {
    kf_->Predict(imu);
    const auto state=kf_->GetDynamicState();
    if(g_lidar_type!=LID_TYPE::OUSTER)propagate_states_.emplace_back(state);
    else if(state.time>propagate_states_.back().time+1e-9)
      propagate_states_.emplace_back(state);
    else if(std::abs(state.time-propagate_states_.back().time)<=1e-9)
      propagate_states_.back()=state;
  }

  static const M3 TLI_R = g_lidar_imu.R_;
  static const V3 TLI_t = g_lidar_imu.t_;
  const SE3 T_end = kf_->GetSE3();
  const M3  R_inv = T_end.R_.transpose();
  const V3  T_end_t = T_end.t_;
  const double start_time = measures_.lidar.start_time;
  auto& raw_pc = measures_.lidar.pc;

  std::size_t ptsize = raw_pc->points.size();
  scan_undistort_full_->resize(ptsize); 

  tbb::parallel_for(
  tbb::blocked_range<size_t>(0, ptsize),
  [&](const tbb::blocked_range<size_t>& r) {
    for (size_t idx = r.begin(); idx < r.end(); ++idx) {  
      auto& pt_full = scan_undistort_full_->points[idx];
      const auto& pt = raw_pc->points[idx];
      pt_full.intensity = pt.intensity;
      double query_time = start_time + pt.offset_time;
      if(g_lidar_type!=LID_TYPE::OUSTER){
        // Preserve the frozen non-Ouster deskew path byte for byte.
        if(query_time>propagate_states_.back().time){
          V3 raw(pt.x,pt.y,pt.z);
          V3 eigen_point=TLI_R*raw+TLI_t;
          pt_full.x=eigen_point[0];pt_full.y=eigen_point[1];pt_full.z=eigen_point[2];
          continue;
        }
        auto match_iter=propagate_states_.begin();
        for(auto iter=propagate_states_.begin();iter!=propagate_states_.end();++iter){
          auto next_iter=std::next(iter);
          if(iter->time<query_time&&next_iter->time>=query_time){
            match_iter=iter;
            break;
          }
        }
        auto match_iter_n=std::next(match_iter);
        double dt=match_iter_n->time-match_iter->time;
        double tau=query_time-match_iter->time;
        double s=tau/dt;
        M3 R_h=match_iter->R,R_t=match_iter_n->R;
        V3 p_h=match_iter->p,v_h=match_iter->v,acc_t=match_iter_n->a;
        M3 R_i=Quat(R_h).slerp(s,Quat(R_t)).toRotationMatrix();
        V3 p_i=p_h+v_h*tau+0.5*acc_t*tau*tau;
        V3 t_ei=p_i-T_end_t;
        V3 raw(pt.x,pt.y,pt.z);
        V3 eigen_point=R_inv*(R_i*(TLI_R*raw+TLI_t)+t_ei);
        pt_full.x=eigen_point[0];pt_full.y=eigen_point[1];pt_full.z=eigen_point[2];
        continue;
      }
      auto use_raw_point=[&](){
        V3 raw(pt.x, pt.y, pt.z);
        V3 eigen_point = TLI_R * raw + TLI_t;
        pt_full.x = eigen_point[0];
        pt_full.y = eigen_point[1];
        pt_full.z = eigen_point[2];
      };
      if(propagate_states_.size()<2||
         query_time<propagate_states_.front().time-1e-6||
         query_time>propagate_states_.back().time+1e-6){
        use_raw_point();
        continue;
      }
      M3 R_i;
      V3 p_i;
      if(query_time>=propagate_states_.back().time){
        R_i=propagate_states_.back().R;
        p_i=propagate_states_.back().p;
      }else{
        auto tail=std::upper_bound(propagate_states_.begin(),propagate_states_.end(),query_time,
            [](double t,const DynamicState& s){return t<s.time;});
        if(tail==propagate_states_.begin())++tail;
        auto head=std::prev(tail);
        const double dt=tail->time-head->time;
        if(!(dt>0.)){
          use_raw_point();
          continue;
        }
        const double tau=query_time-head->time;
        const double s=tau/dt;
        R_i=Quat(head->R).slerp(s,Quat(tail->R)).toRotationMatrix();
        p_i=head->p+head->v*tau+0.5*tail->a*tau*tau;
      }
      V3 t_ei = p_i - T_end_t;
      V3 raw(pt.x, pt.y, pt.z);
      V3 eigen_point = R_inv * (R_i * (TLI_R * raw + TLI_t) + t_ei);
      pt_full.x = eigen_point[0];
      pt_full.y = eigen_point[1];
      pt_full.z = eigen_point[2];
    }
  });
}


void SuperLIO::DownSample(){
  voxel_grid_fliter_.setInputCloud(scan_undistort_full_);
  voxel_grid_fliter_.filter(ds_undistort_);
}


struct ThreadACC{
  M6d HTVH = M6d::Zero();
  V6d HTVr = V6d::Zero();
  ThreadACC(): HTVH(M6d::Zero()), HTVr(V6d::Zero()) {}
};


void SuperLIO::Observe(){
  if(photo_->enabled()) photo_->prepare(measures_, propagate_states_, kf_->GetSE3());
  if(coin_->enabled()) coin_->prepare(measures_.lidar,propagate_states_,kf_->GetSE3());
  const bool capture_geometry_rows=coin_->enabled()||photo_->needsGeometryRows()||geometry_rows_audit_.is_open();
  size_t ptsize = ds_undistort_->size();
  
  static std::vector<float> _lengths;
  points_body_v3_.resize(ptsize);
  _lengths.resize(ptsize);

  effect_knn_num_ = ptsize;
  std::iota(effect_knn_idxs_.begin(), effect_knn_idxs_.begin() + ptsize, 0);

  for(size_t i = 0; i < ptsize; ++i){
    const auto& point_body_pcl = ds_undistort_->points[i];
    points_body_v3_[i] = V3(point_body_pcl.x, point_body_pcl.y, point_body_pcl.z);
    _lengths[i] = points_body_v3_[i].norm();
  }

  ivox_->reset_max_group();
  int iter_num = 0;
  Eigen::MatrixXd geometry_translation_rows_final(0,3);
  Eigen::VectorXd geometry_translation_residuals_final(0);

  kf_->UpdateObserve([&, this](const ESKF::KFState &kf_state, M6 &HTVH, V6 &HTVr) {
    const SE3 pose = kf_state.pose;
    const bool need_converge = kf_state.need_converge;
    const M3d R_transpose = (pose.R_.transpose()).cast<double>();

    tbb::enumerable_thread_specific<ThreadACC> tls_acc;
    std::vector<Eigen::Vector3d> geometry_translation_rows;
    std::vector<std::uint8_t> geometry_translation_valid;
    std::vector<double> geometry_translation_residuals;
    if(capture_geometry_rows){
      geometry_translation_rows.assign(points_body_v3_.size(),Eigen::Vector3d::Zero());
      geometry_translation_valid.assign(points_body_v3_.size(),0);
      geometry_translation_residuals.assign(points_body_v3_.size(),0.);
    }

    tbb::parallel_for(
      tbb::blocked_range<size_t>(0, effect_knn_num_),
      [&](const tbb::blocked_range<size_t>& r) {
        KNNHeapType top_K;
        auto& local_acc = tls_acc.local();
        for (size_t r_s = r.begin(); r_s < r.end(); ++r_s) {
          int idx = effect_knn_idxs_[r_s];
          V3& point_body = points_body_v3_[idx];
          V3 point_world = pose * point_body;

          if(!need_converge){
            top_K.reset();
            ivox_->getTopK(point_world, top_K);
            if(top_K.count < 4){
              effect_mask_[idx] = false;
              effect_knn_mask_[idx] = false;
              continue;
            }
            effect_knn_mask_[idx] = true;
            effect_mask_[idx] = calc_plane_coeff(top_K.count, top_K.points_, abcd_vec_[idx]);
          }

          if(!effect_mask_[idx]) continue;

          auto& abcd = abcd_vec_[idx];
          scalar error;
          effect_mask_[idx] = compute_error(abcd, point_world, _lengths[idx], error);
          if(!effect_mask_[idx]) continue;
          
          {
            V3d normvec(abcd[0], abcd[1], abcd[2]);
            V3d nb = R_transpose * normvec;
            V3d point_body_d = point_body.cast<double>();
            V6d J;
            J.head<3>() = point_body_d.cross(nb);
            J.tail<3>() = normvec;
            if(capture_geometry_rows){
              geometry_translation_rows[idx]=normvec.cast<double>();
              geometry_translation_valid[idx]=1;
              geometry_translation_residuals[idx]=static_cast<double>(error);
            }
      
            local_acc.HTVH += J * 1000 * J.transpose();
            local_acc.HTVr -= J * 1000 * error;
          }
        }
    });

    M6d sum_HTVH = M6d::Zero();
    V6d sum_HTVr = V6d::Zero();
    for(const auto& local_acc : tls_acc){
      sum_HTVH += local_acc.HTVH;
      sum_HTVr += local_acc.HTVr;
    }
    HTVH = sum_HTVH.cast<scalar>();
    HTVr = sum_HTVr.cast<scalar>();
    if(photo_->enabled()) photo_->add(pose, HTVH, HTVr, kf_->GetCov().topLeftCorner<6,6>());
    if(capture_geometry_rows){
      std::size_t row_count=0;
      for(std::size_t r_s=0;r_s<effect_knn_num_;++r_s){
        const int idx=effect_knn_idxs_[r_s];row_count+=geometry_translation_valid[idx]!=0;
      }
      geometry_translation_rows_final.resize(row_count,3);
      geometry_translation_residuals_final.resize(static_cast<Eigen::Index>(row_count));
      std::size_t row=0;
      for(std::size_t r_s=0;r_s<effect_knn_num_;++r_s){
        const int idx=effect_knn_idxs_[r_s];
        if(!geometry_translation_valid[idx])continue;
        geometry_translation_rows_final.row(row++)=geometry_translation_rows[idx].transpose();
        geometry_translation_residuals_final[static_cast<Eigen::Index>(row-1)]=
            geometry_translation_residuals[idx];
      }
      coin_->add(pose,HTVH,HTVr);
    }

    if(need_converge) return;

    int _effect_knn_num = 0;
    for(size_t i = 0; i < effect_knn_num_; ++i){
      int idx = effect_knn_idxs_[i];
      if(!effect_knn_mask_[idx]) continue;
      effect_knn_idxs_[_effect_knn_num] = idx;
      _effect_knn_num++;
    }

    // LOG(INFO) << "effect_knn_num_: " << effect_knn_num_ << ", _effect_knn_num: " << _effect_knn_num;
    effect_knn_num_ = _effect_knn_num;

    iter_num++;
  });

  if(geometry_rows_audit_){
    const std::uint32_t frame=static_cast<std::uint32_t>(geometry_rows_audit_frame_++);
    const double timestamp=measures_.lidar.end_time;
    const std::uint32_t effective_points=static_cast<std::uint32_t>(ds_undistort_->size());
    const std::uint32_t row_count=static_cast<std::uint32_t>(geometry_translation_rows_final.rows());
    geometry_rows_audit_.write(reinterpret_cast<const char*>(&frame),sizeof(frame));
    geometry_rows_audit_.write(reinterpret_cast<const char*>(&timestamp),sizeof(timestamp));
    geometry_rows_audit_.write(reinterpret_cast<const char*>(&effective_points),sizeof(effective_points));
    geometry_rows_audit_.write(reinterpret_cast<const char*>(&row_count),sizeof(row_count));
    for(std::uint32_t row=0;row<row_count;++row){
      for(int col=0;col<3;++col){
        const double value=geometry_translation_rows_final(row,col);
        geometry_rows_audit_.write(reinterpret_cast<const char*>(&value),sizeof(value));
      }
      const double residual=geometry_translation_residuals_final[row];
      geometry_rows_audit_.write(reinterpret_cast<const char*>(&residual),sizeof(residual));
    }
    geometry_rows_audit_.flush();
  }

  if(photo_->enabled()) photo_->finish(kf_->GetSE3(), kf_->GetNavState().timestamp,
                                       geometry_translation_rows_final);
  if(coin_->enabled()) coin_->finish(kf_->GetSE3(),kf_->GetNavState().timestamp,
                                     geometry_translation_rows_final);
  frame_num_++;
}


void SuperLIO::UpdateMap() {
  const size_t ptsize = ds_undistort_->size();
  if (ptsize == 0) return;
  
  last_pose_ = kf_->GetSE3();
  points_world_v3_.resize(ptsize);
  
  const auto R = last_pose_.R_;
  const auto t = last_pose_.t_;
  
  for (size_t i = 0; i < ptsize; ++i) {
    const auto& pt = points_body_v3_[i];
    points_world_v3_[i] = R * pt + t;
  }
  
  ivox_->insert(points_world_v3_);

}


void SuperLIO::Output(){
  auto state = kf_->GetNavState();
  data_wrapper_->pub_odom(state);  

  Eigen::Matrix4f transformation = Eigen::Matrix4f::Identity();
  transformation.block<3, 3>(0, 0) = state.R.R_.cast<float>();
  transformation.block<3, 1>(0, 3) = state.p.cast<float>();

  CloudPtr world_pc(new PointCloudType());
  
  if(g_visual_map){
    static int count = -1;
    count++;
    if(count % g_pub_step != 0){
      return;
    }
    count = 0;
    if(g_visual_dense){
      pcl::transformPointCloud(*scan_undistort_full_, *world_pc, transformation);
      data_wrapper_->pub_cloud_world(world_pc, state.timestamp);
    }else{
      pcl::transformPointCloud(*ds_undistort_, *world_pc, transformation);
      data_wrapper_->pub_cloud_world(world_pc, state.timestamp);
    }
  }
}

void SuperLIO::printTimeRecord(){
  if(!g_time_eva) return;
  time_record_.PrintAll();
}

} // namespace END.
